using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class GrapplingPlug : MonoBehaviour
{
    [SerializeField] 
    Camera mainCamera;
    

    [Header("Grappling Hook Variables")]
    [SerializeField]
    private LineRenderer GrappleRope;
    [SerializeField] 
    private DistanceJoint2D PivotePoint;
    [SerializeField]
    private float swingSpeed;

    [Header("Components")]
    Rigidbody2D rb;
    
    // Start is called before the first frame update
    void Start()
    {
        //disabling pivot point until mouse click
        PivotePoint.enabled = false;
        rb = GetComponent<Rigidbody2D>();

    }

    // Update is called once per frame
    void Update()
    {
        // shooting the grappling hook
        if (Input.GetKeyDown(KeyCode.Mouse0))
        {
            // getting mouse pos
            Vector2 mousePos = (Vector2)mainCamera.ScreenToWorldPoint(Input.mousePosition);
            //deciding the starting and end points of the rope
            GrappleRope.SetPosition(0, mousePos);
            GrappleRope.SetPosition(1, transform.position);
            //enabling pivot point and making it equal to put pos
            PivotePoint.enabled = true;
            PivotePoint.connectedAnchor = mousePos;
            GrappleRope.enabled = true;
        }
        else if (Input.GetKeyUp(KeyCode.Mouse0))
        {
            //disabling grappling hook
            PivotePoint.enabled = false;
            GrappleRope.enabled = false;
        }
        if (PivotePoint.enabled) 
        {
            GrappleRope.SetPosition(1, transform.position);
            
        }

        Swing(swingSpeed);
    }


    void Swing(float speed) {


        if (Input.GetKeyDown(KeyCode.A)) {

            Vector2 force = new Vector2(-speed * Time.deltaTime, 0f);
            rb.AddForce(force);

        }
        else if (Input.GetKeyDown(KeyCode.D)) {

            Vector2 force = new Vector2(speed * Time.deltaTime, 0f);
            rb.AddForce(force);

        }
        

    }
}
